package Question1;

public class question1 {
	public class Box<T> {
		  private T object;

		  public void set(T object) {
		    this.object = object;
		  }

		  public T get() {
		    return object;
		  }
		}
}



