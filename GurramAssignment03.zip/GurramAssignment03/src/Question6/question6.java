package Question6;

public class question6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Using String
        String s = "Hello";
        s = s + " World";
        System.out.println("String: " + s);

        // Using StringBuffer
        StringBuffer stringBuffer = new StringBuffer("Hello");
        stringBuffer.append(" World");
        System.out.println("StringBuffer: " + stringBuffer);
    }


	}


