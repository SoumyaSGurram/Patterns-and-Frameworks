package Question7;

public class question7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final int id; 
		     
	    public question7(int id) { 
	        this.id = id; 
	    } 
	     
	    // other methods 


	}

}
