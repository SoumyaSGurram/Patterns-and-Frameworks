package Question13;

import java.util.ArrayList;
import java.util.Vector;

public class question13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<String> vector = new Vector<>();
        vector.add("ap");
        vector.add("ba");
        vector.add("or");
        System.out.println("Vector: " + vector);

        // Using ArrayList
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("ap");
        arrayList.add("ba");
        arrayList.add("or");
        System.out.println("ArrayList: " + arrayList);

	}

}
