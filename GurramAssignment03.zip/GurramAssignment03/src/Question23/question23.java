package Question23;

public final class question23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		    final int value;

		    public question23(int value) {
		        this.value = value;
		    }

		    public int getValue() {
		        return value;
		    }
		}


	
}

