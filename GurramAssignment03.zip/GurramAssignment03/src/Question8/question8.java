package Question8;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class question8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try (BufferedReader reader = new BufferedReader(new FileReader("file.txt"))) { 
		    // code that uses the BufferedReader 
		} catch (IOException e) { 
		    // exception handling code 
		} 
		 

	}

}
