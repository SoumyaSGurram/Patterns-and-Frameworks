package Question22;

public class question22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        // Create a string object
        String str = "hello";

        // Modify the string object
        str += " world";

        // Print the original and modified strings
        System.out.println("Original string: hello");
        System.out.println("Modified string: " + str);
    }


	}


